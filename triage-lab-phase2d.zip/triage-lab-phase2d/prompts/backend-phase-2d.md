# Backend Phase 2d — M3 Readiness: Provider Trace, Cached Tokens, Open-Weight Provider Selection

You are a **senior Python backend engineer** with hands-on experience with OpenRouter's provider routing, usage accounting, and LLM latency diagnosis. You continue the `backend/` project of the AI Triage Agent Lab. M2 is accepted (`docs/reports/M2-integration.md`). Before internal QA (M3) starts, this short phase closes three gaps from the 2b-2 and 2c reports: the serving provider is not recorded, cached prompt tokens are not stored (so the estimate overstates OpenAI/DeepSeek cost), and `b-gptoss120b` — the only self-hostable candidate — was gated off, possibly because of provider routing rather than the model. The machine is Windows 11 with Docker Desktop; use PowerShell-compatible commands. A system proxy intercepts `localhost` for Python HTTP clients: use `NO_PROXY=localhost` or `trust_env=False` for host-side checks.

## 1. Read first

1. `backend/CLAUDE.md`
2. `docs/decisions.md` — **D-040 … D-043**, and D-025, D-033, D-036, D-037, D-038
3. `docs/reports/M2-integration.md`
4. `backend/docs/reports/phase-2b2-model-set.md` (§4, §6, §8, §9) and `phase-2c-cost-accounting.md` (§2, §3, §10)
5. OpenRouter documentation for provider routing (`provider.order`, `allow_fallbacks`, `data_collection`) and the per-model endpoints listing (`GET /api/v1/models/{author}/{slug}/endpoints`) — read the current docs; do not rely on memory
6. `backend/docs/decisions.md`, `backend/docs/progress.md`

## 2. Rules

- **Boundary.** Write only inside `backend/`. Never edit `docs/`, `web/`, `AGENT_SPEC.md`, `BACKEND_ARCHITECTURE.md`. Prompts stay frozen.
- **No contract change.** No new API response fields. New DB columns appear in the CSV exports automatically (B-022); that is allowed.
- **Privacy is not negotiable:** `data_collection: "deny"` stays on every request. Never set `allow_fallbacks: false` in a way that bypasses it (it does not, but check the request body in a test).
- **Budget:** at most **USD 1.50** of reported OpenRouter cost. Check `/key` usage before and after each real run.
- **Config changes** only as allowed by D-041 (T3) and the D-025 evidence table. Model, reasoning, deadlines, and prompts are unchanged.
- **Schema.** New columns make old databases fail the v1.2 schema check — this is expected. The check's message must now say "older than the current schema" (not "v1.2"). Delete old DB files only under `backend/data/` and only those you created; if a running process holds `data/dev.db`, do not kill it — use a new DB path and say so.
- **Git (D-027, D-033):** `git add -- backend` then `git commit -m "backend: …" -- backend`. Never commit `.env` or `backend/data/`.
- **Per-task loop:** implement → tests → `uv run pytest -q`, `uv run ruff check .`, `uv run ruff format --check .` green, guard coverage 100% → update `backend/docs/progress.md` and `backend/docs/decisions.md` → commit.

## 3. Tasks

### T1 — Record the serving provider

- Parse the provider name from each OpenRouter response (the top-level `provider` field of the chat-completion response; check the current docs for the exact key). Store it in a new nullable column `llm_calls.provider`. Deadline-cut or transport-failed calls have `null`.
- Show it in the smoke-test table (a `provider` column, the value of the last call per turn) and in the `--json` output per call.
- `cost-report` gains `--by provider` (group key `model / provider`, same columns as the other groupings).

**Tests (FakeLLM + recorded response fixtures):** the provider is stored; a response without the field → `null`; the smoke table and JSON show it; `cost-report --by provider` aggregates.
**Done when:** the tests pass.

### T2 — Cached prompt tokens (D-042)

- Store `usage.prompt_tokens_details.cached_tokens` (or the current equivalent) in `llm_calls.cached_prompt_tokens` (nullable), and add `sessions.total_cached_prompt_tokens`.
- Pricing entries gain an **optional** `input_cache_read_per_mtok`. Fill it from `/models` (`pricing.input_cache_read` × 1e6) for every model that lists it; leave it out otherwise. Update `as_of`.
- Estimate: `(prompt − cached) × input + cached × cache_read + completion × output`, per 1e6. Without a cache price or without cached tokens, the formula is unchanged.
- `cost-report` adds `cached_prompt_tokens` (sum, mean) to every grouping.
- Recompute the phase-2b-2 comparison offline from the stored smoke JSON files if they contain the cached-token field; otherwise say so. Do not spend money for this.

**Tests:** the estimate with and without cached tokens and with and without a cache price (known numbers); session total of cached tokens; `cost-report` columns; the registry accepts the optional field and rejects a negative value.
**Done when:** the tests pass.

### T3 — Provider selection for the open-weight models (D-041)

1. **Registry:** add an optional per-model `provider_order: [string, …]` to the `pricing`-level model entry or a new top-level `providers` map keyed by model slug (choose one, record the choice as a `B-xxx`). When set, `OpenRouterClient` sends `provider.order` with `allow_fallbacks: true`, keeping `data_collection: "deny"`. Only `openai/gpt-oss-120b` and `deepseek/deepseek-v4-pro-0813` may have it; the registry rejects it for other models. It is part of the session snapshot.
2. **Candidates:** read `GET /api/v1/models/openai/gpt-oss-120b/endpoints` (and the same for DeepSeek 0813). List every provider with its advertised latency/throughput, context, and whether it supports `response_format` and `reasoning`. Keep only providers that support both.
3. **Measure (gpt-oss-120b):** for each candidate (at most 4, fastest advertised first), run the smoke test for `b-gptoss120b` and `a-gptoss120b` only, **twice**, with `provider_order: [<candidate>]` set temporarily (`uv run python -m app.cli smoke-test --agent b-gptoss120b …` — use the existing agent filter). A candidate that answers from a different provider (T1 column) counts as "not served"; skip it. Record per candidate: pass/fail per run, reason, p50/max turn latency, repairs, cost.
4. **Decide (the rule in D-041, no judgment calls):** a candidate qualifies if `b-gptoss120b` passes the conclusion in **both** runs; among qualifying candidates, the lowest p50 over `b-gptoss120b`'s turns wins. Set `provider_order: [<winner>]` for gpt-oss. If none qualifies, leave `provider_order` unset.
5. **Re-gate:** apply the D-036 gate to `b-gptoss120b` with the winner's two runs (conclusion passes in both runs and every turn ≤ 75 s). If it passes, set `enabled: true` with `# D-036 gate re-check: passed with provider <X> (B-xxx)`. If it fails, it stays disabled; report the numbers. `a-gptoss120b` stays disabled either way (A agents are enabled only for Sonnet and GPT-5.4, D-012).
6. **DeepSeek (optional within budget):** repeat steps 3–4 for `b-deepseekv4pro` with at most 3 candidates. Pin a provider only if it passes both runs **and** its p50 is at least 25% lower than the 2b-2 value (29.6 s). Otherwise leave it unpinned.
7. Every change gets a YAML comment and a `B-xxx` with the numbers.

**Tests:** the request body contains `provider.order` and still `data_collection: "deny"` when configured, and no `order` otherwise; the registry rejects `provider_order` for a non-open-weight model; the snapshot contains it.
**Done when:** the measurements are recorded and the rule has been applied.

### T4 — Fresh M3 database and QA accounts helper

M3 runs on a clean `lab.db` with the current schema. Add a small, documented helper so the product owner can prepare it without mistakes:

- `uv run python -m app.cli init-qa --admin <username> --evaluator <username>`: refuses to run if `DATABASE_PATH` already exists (unless `--force`, which first moves the old files to `data/archive/<timestamp>/`), creates the schema, syncs the agents, and creates the two users with passwords read from stdin (two lines: admin, evaluator; same validation as `create-user`). It prints the enabled agents (display name + id) at the end, for the QA protocol's assignment step.
- Document it in the README with a PowerShell example, and the equivalent command inside the compose container.

**Tests:** refuses on an existing DB; `--force` archives and recreates; the users exist with the right roles; the printed list matches `enabled`.
**Done when:** the tests pass. **Do not run it against the real `data/lab.db`.**

### T5 — Report

Write **`backend/docs/reports/phase-2d-m3-readiness.md`** in English: summary (the M3 agent set, spend); T1 provider column and what the 2d runs show per model; T2 cached tokens, cache prices, and the offline re-comparison if possible; T3 candidate table per model, the rule's outcome, the re-gate result; T4 usage; new `B-xxx`; known issues; next steps (M3). Update `progress.md`, `decisions.md`, README.

**Done when:** the report is written and everything is committed.

## 4. Definition of done (phase)

- Every LLM call stores its serving provider and cached prompt tokens; the estimate uses cache prices where available.
- gpt-oss-120b (and optionally DeepSeek) has been measured per provider and the D-041 rule applied; `b-gptoss120b` is re-gated.
- `init-qa` prepares a clean M3 database with two accounts.
- Spend ≤ USD 1.50; tests, ruff, guard coverage green; report, progress, decisions committed with `backend:` prefixes.
