# Backend Phase 2b-2 — Final Model Set, Turn Deadline, M3 Gate

You are a **senior Python backend engineer** (FastAPI, asyncio, httpx, Pydantic v2, pytest) with hands-on experience integrating LLM APIs through OpenRouter. You continue the `backend/` project of the AI Triage Agent Lab. Phase 2b verified the real-model path on the **previous** model set (report `backend/docs/reports/phase-2b-real-model-verification.md`). The product owner has now fixed the final model set, decided on your §5.5 recommendations, and added one model. This phase applies those decisions and verifies the changed models. The machine is Windows 11 with Docker Desktop; use PowerShell-compatible commands.

## 1. Read first

1. `backend/CLAUDE.md`
2. `docs/decisions.md` — **D-034** (revised), **D-036, D-037, D-038**, and D-025, D-033
3. `backend/docs/BACKEND_ARCHITECTURE.md` **v1.2** — §6.3 (deadlines), §8 (agent table), §13 (settings). Ignore §8a (it belongs to phase 2c).
4. `docs/PRD.md` §10 NFR-2 (revised) and §11
5. `backend/docs/reports/phase-2b-real-model-verification.md`, `backend/docs/decisions.md`, `backend/docs/progress.md`

## 2. Rules

- **Boundary.** Write only inside `backend/`. Never edit `docs/`, `web/`, `AGENT_SPEC.md`, `BACKEND_ARCHITECTURE.md`. Prompts stay frozen (no change under `app/agents/prompts/v1/`).
- **Budget.** At most **USD 3** of reported OpenRouter cost for this phase. Check `/key` usage before and after each run and stop real calls when the next run could exceed the budget.
- **Config changes** are only those listed in T1 and T4, plus the D-025 evidence table (repeated in T3). Nothing else.
- **Privacy is not negotiable.** `provider.data_collection = "deny"` stays for every model. If a model has no provider under that setting, report it; do not remove the setting.
- **Git (D-027, D-033):** `git add -- backend` then `git commit -m "backend: …" -- backend`. Never commit `.env` or `backend/data/`.
- **Per-task loop:** implement → tests → `uv run pytest -q`, `uv run ruff check .`, `uv run ruff format --check .` green, guard coverage 100% → update `backend/docs/progress.md` and `backend/docs/decisions.md` → commit.

## 3. Tasks

### T1 — Final model set (D-034, D-036)

1. Fetch `GET https://openrouter.ai/api/v1/models` and confirm that each of these exists **exactly**: `openai/gpt-5.4`, `anthropic/claude-sonnet-5.5`, `google/gemini-3.1-pro-preview`, `openai/gpt-5.4-mini`, `google/gemini-3-flash-preview`, `deepseek/deepseek-v4-pro-0813`, `openai/gpt-oss-120b`. If any is missing, do not substitute: stop the phase and report the missing id and the closest ids you saw.
2. Update `config/agents.yaml` to the table in `BACKEND_ARCHITECTURE.md §8`, with a `# D-034` / `# D-036` comment on each changed line:
   - `b-sonnet5` → `b-sonnet55`, `a-sonnet5` → `a-sonnet55`, model `anthropic/claude-sonnet-5.5`;
   - `b-gpt5mini` → `b-gpt54mini`, `a-gpt5mini` → `a-gpt54mini`, model `openai/gpt-5.4-mini`;
   - both DeepSeek agents → model `deepseek/deepseek-v4-pro-0813`, `reasoning_effort: minimal`, `max_tokens: 8000`;
   - new `b-gptoss120b` (structured, `display_name` «دکتر ۱۳», **enabled**) and `a-gptoss120b` (simple, «دکتر ۱۴», disabled), defaults otherwise;
   - every other agent's `display_name`, `enabled`, and config unchanged.
   Retired ids stay in the `agents` table as disabled (B-014).
3. Update tests, fixtures, README, and smoke expectations that name the old ids or slugs. Record a `B-xxx` decision.

**Tests:** the registry loads the new file (14 agents, 9 enabled, unique display names); the DeepSeek agents' merged config has `minimal` / 8000; the retired ids become disabled on `sync_to_db`.
**Done when:** the tests pass.

### T2 — Turn deadline (D-038)

Implement `BACKEND_ARCHITECTURE.md §6.3` "Deadlines":

- New settings `LLM_CALL_DEADLINE_SECONDS` (default 50) and `TURN_DEADLINE_SECONDS` (default 80); `LLM_TIMEOUT_SECONDS` stays as the httpx per-read timeout. Add them to `.env.example` and the README. Do not edit `backend/.env`; the defaults apply.
- A turn budget object is created by the session service for each `next_turn` / `force_conclude` and passed down (e.g. through `SessionContext`) to the json_runner and the LLM client. Each call runs under a total deadline of `min(LLM_CALL_DEADLINE_SECONDS, remaining)` (`asyncio.timeout` / `wait_for` around the whole request, including reading the body). A transport retry or a repair starts only if at least 15 s of the turn budget remain.
- On expiry: the attempt is traced with `error = "deadline_exceeded"` and its latency; the turn ends as 502 `AGENT_ERROR` with the standard body; the session stays active; the lock is released (the existing `finally`). The resend path works as before.
- Architecture B: the turn call and the assessment call share one budget. If the turn call leaves less than 15 s, skip the assessment call and end with the same 502 (the new clinical state is still saved, B-011).
- Smoke test: uses the same deadlines, and its table shows `deadline` as the failure reason when it happens.

**Tests (FakeLLM with controllable delays, patched clock or small deadlines — no real waiting over ~1 s):** a slow single call → `deadline_exceeded` trace + 502 + lock released; a repair is skipped when < 15 s remain; B skips the assessment call when the budget is short and still persists the clinical state; a resend after a deadline error succeeds; a slow stream that sends data continuously (per-read timeout never fires) is still cut by the total deadline.
**Done when:** the tests pass.

### T3 — Smoke test of the final set

1. Run `uv run python -m app.cli smoke-test --include-disabled --json data/smoke-2b2-run1.json`, then a second run (`…-run2.json`). All 14 agents.
2. Apply only the D-025 evidence fixes, per model, each with a YAML comment and a `B-xxx` quoting the provider's error text:

   | Evidence | Fix |
   |---|---|
   | The provider rejects `temperature` | `send_temperature: false` for that model |
   | The provider rejects `response_format` / `json_object` | `output_mode: prompt_only` for that model |
   | The provider rejects the `reasoning` parameter or the effort value (including `minimal`) | the nearest accepted effort (`minimal` → `low`), or `reasoning_effort: null` if none is accepted |
   | Any architecture-A agent mishandles a conversation that starts with the `assistant` greeting | greeting fallback for all A agents (`§6.1`), unit-tested |
   | No provider available under `data_collection: deny` | no fix; report |
   | Anything else | no fix; report with the trace excerpt |

3. Re-run (within budget) after fixes until every agent passes or its failure is in a "no fix" row.

**Tests:** unit tests for any code change; registry tests pass with the final file.
**Done when:** a final pair of runs exists for all 14 agents.

### T4 — Apply the M3 gate (D-036) and check the targets (D-037)

1. **Gate:** for every **enabled** agent, if it failed the conclusion in either final run, or any of its turns took more than 75 s, set `enabled: false` with a comment `# D-036 gate: <reason>` and a `B-xxx`. Do not tune it further in this phase.
2. **Targets:** per agent, compute p50 / p90 / max turn latency over question and finish turns from the final runs and compare with D-037 (A: p50 ≤ 8 s, p90 ≤ 25 s; B: p50 ≤ 20 s, p90 ≤ 45 s; any turn ≤ 75 s). Report misses; do not change reasoning, models, or deadlines to meet them.
3. Run the Compose + nginx check of phase 2b T5 again, with `b-sonnet55` and `b-gptoss120b`: two patient messages each and one `finish`, same database precautions (back up or delete the `lab.db*` files the check creates, and confirm the state afterwards).

**Done when:** the gate is applied, the targets table is complete, and the compose run passed.

### T5 — Report

Write **`backend/docs/reports/phase-2b2-model-set.md`** in English:

1. summary (enabled agents after the gate, total spent);
2. the model-set change (old → new slug per agent, `/models` check);
3. the deadline implementation and its tests;
4. the smoke table for all 14 agents (as in phase 2b, plus the failure reason column);
5. config changes with evidence;
6. the D-036 gate result and the D-037 targets table;
7. the compose run;
8. qualitative notes on the Persian replies of the **changed and new** models (Sonnet 5.5, GPT-5.4 Mini, DeepSeek 0813, gpt-oss-120b), in the style of the phase-2b report §7;
9. known issues and next steps.

Update `backend/docs/progress.md`, `backend/docs/decisions.md`, README.

**Done when:** the report is written and everything is committed.

## 4. Definition of done (phase)

- The final model set is in `agents.yaml`, every slug verified; DeepSeek has the D-036 config; the gpt-oss agents exist.
- The 80 s turn / 50 s call deadlines are implemented and tested; the backend always answers before the web client's 90 s timeout.
- Two final smoke runs cover all 14 agents; the D-036 gate is applied; the D-037 table is reported.
- Compose + nginx works with the new models, and the real database is left as it was.
- Spend ≤ USD 3; tests, ruff, guard coverage green; everything committed with `backend:` prefixes.
