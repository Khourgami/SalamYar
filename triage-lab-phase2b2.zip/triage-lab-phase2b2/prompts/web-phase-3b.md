# Web Phase 3b — Contract v1.2: Tokens and Cost

**Start after backend phase 2c is complete and committed.**

You are a **senior frontend engineer** (React 18, TypeScript strict, TanStack Query, MSW, Vitest + RTL) experienced in Persian RTL interfaces. You continue the `web/` project. Contract v1.2 adds token and call counts to the result card stats and new cost/token columns to the admin metrics. Cost, tokens, and call count are **hidden from evaluators until they have evaluated**, because they would hint at the model and architecture (D-035). It also adds a slow-turn hint to the typing bubble (D-039). This is a small phase.

## 1. Read first

1. `web/AGENTS.md`
2. `docs/decisions.md` — D-007, D-035, D-038, D-039
3. `docs/API_CONTRACT.md` **v1.2** — changelog, `ResultCard.stats`, `MetricsRow`
4. `web/docs/UI_SPEC.md` **v1.2** — §3.3 typing bubble and Stats row, §3.5 metric columns
5. `web/docs/decisions.md`, `web/docs/progress.md`, `backend/docs/reports/phase-2c-cost-accounting.md` (read only)

## 2. Rules

- Write only inside `web/`. No visual redesign; reuse the existing primitives and tokens.
- Persian copy verbatim from UI_SPEC v1.2 (labels: «هزینه»، «تعداد فراخوانی مدل»، «توکن ورودی»، «توکن خروجی»، «توکن استدلال»، «هزینه کل»، «میانگین فراخوانی مدل»، «میانگین توکن ورودی»، «میانگین توکن خروجی»، «میانگین توکن استدلال»).
- A `null` stats value is **not rendered at all** — no «—», no placeholder, no empty label. The DOM before evaluation must not reveal that a hidden value exists.
- **Git (D-027, D-033):** from inside `web/`: `git add -- .` then `git commit -m "web: …" -- .`. Never commit `.env`.
- **Per-task loop:** implement → tests → `npm run build`, `npm run lint`, `npm run test` green → update `web/docs/progress.md` and `web/docs/decisions.md` → commit.

## 3. Tasks

### T1 — Types and mocks

- `src/api/types.ts`: the v1.2 fields of `ResultCard.stats` and `MetricsRow`, exactly as in the contract.
- MSW: the stats fields are `null` for an evaluator until the session is evaluated and filled afterwards; admins always get values (`/admin/sessions/{id}`); `/admin/metrics` rows include the new fields (some `null` in at least one row).
- `src/integration/helpers.ts`: update the hand-written key sets for `ResultCard.stats` and `MetricsRow`.

**Tests:** handler tests for null-before / values-after evaluation and admin values.
**Done when:** the tests pass.

### T2 — Result card stats

Render the new values after the existing three stats, only when non-null: cost in USD with 4 decimals (existing `usd`), counts and tokens with Persian digits and thousands separators (add `faInteger` to `lib/format.ts` if no equivalent exists).

**Tests:** before evaluation, none of the five labels is in the DOM and no USD value appears; after evaluation, all five render with correct formatting; the admin detail shows them for an unevaluated session; extend the blindness probe test so that a `$` amount or the five labels before evaluation fail it.
**Done when:** the tests pass.

### T3 — Admin metrics table

Add the five new columns to `MetricsTable` (sortable like the others; `null` sorts last and renders the existing empty value). `total_cost_usd` and `mean_cost_usd` use `usd`; the means use one decimal with Persian digits. The dashboard cards and chart are unchanged.

**Tests:** the new headers render; sorting by «هزینه کل» works with a `null` row last.
**Done when:** the tests pass.

### T4 — Slow-turn hint (D-039)

While a turn (`POST /messages`, `POST /finish`, or a resend) is running, the typing bubble adds the caption «پاسخ ممکن است تا یک دقیقه طول بکشد.» after 15 s. The timer resets for every new turn and the line disappears when the turn ends (success, error, or timeout). The text is from UI_SPEC v1.2 (not invented).

**Tests (fake timers):** hidden at 14.9 s, shown at 15 s, gone after the reply; a new turn starts hidden again; the line is inside the typing bubble and the existing «پزشک در حال بررسی…» text is unchanged.
**Done when:** the tests pass.

### T5 — Integration check and report

1. Against the backend dev server (`uv run python -m app.dev_server --seed` on a fresh `data/dev.db`, see the backend 2c report): `npm run test:int` passes with the updated key sets, plus one new scenario — an evaluator's completed-unevaluated session has the five fields `null`, the evaluated one has numbers, and the admin sees numbers.
2. Browser check at 1280 and 375 px: stats hidden before evaluation, shown after; the metrics table scrolls horizontally without page overflow; with `--delay-ms 16000` on the dev server, the slow-turn hint appears. Re-run the blindness probe.
3. Write **`web/docs/reports/phase-3b-cost-fields.md`**: summary, changes, tests (count before/after), integration and browser results, decisions, known issues.

**Done when:** everything passes and is committed.

## 4. Definition of done (phase)

- v1.2 types and mocks; stats render only non-null values; five new metric columns; the slow-turn hint.
- No cost, token, or call-count information visible to an evaluator before evaluation (unit test + browser probe).
- `npm run test`, `npm run test:int`, build, lint green; report committed with `web:` prefixes.
