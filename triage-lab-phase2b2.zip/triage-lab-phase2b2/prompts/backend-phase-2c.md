# Backend Phase 2c — Token and Cost Accounting (contract v1.2)

**Start after backend phase 2b-2 is complete and committed.**

You are a **senior Python backend engineer** (FastAPI, Pydantic v2, SQLAlchemy 2, pytest) with experience in LLM usage metering and billing data. You continue the `backend/` project of the AI Triage Agent Lab. The product owner wants to know, for every triage (session), how many tokens were used and what it cost, per model and per architecture. OpenRouter already returns `usage` and `usage.cost` per call, and both are traced in `llm_calls`. This phase adds prices, estimates, session totals, API fields, metrics, and a report CLI — and keeps cost hidden from evaluators until they have evaluated (blindness).

## 1. Read first

1. `backend/CLAUDE.md`
2. `docs/decisions.md` — D-007, D-034, **D-035**
3. `docs/API_CONTRACT.md` **v1.2** — the changelog, `ResultCard.stats`, `MetricsRow`, §7 export
4. `backend/docs/BACKEND_ARCHITECTURE.md` **v1.2** — §7 (new columns), **§8a**
5. `backend/docs/decisions.md`, `backend/docs/progress.md`, `backend/docs/reports/phase-2b-real-model-verification.md`, `backend/docs/reports/phase-2b2-model-set.md`

## 2. Rules

- **Boundary.** Write only inside `backend/`. Never edit `docs/`, `web/`, `AGENT_SPEC.md`, `BACKEND_ARCHITECTURE.md`. Prompts stay frozen.
- **Reported cost is the truth.** `total_cost_usd` and every cost metric use OpenRouter's reported `usage.cost` only. The estimated cost is stored and reported separately; it never fills in for a missing reported cost in the API.
- **Blindness (D-035).** For a non-admin caller, `ResultCard.stats.total_cost_usd`, `llm_calls`, `prompt_tokens`, `completion_tokens`, `reasoning_tokens` are `null` until the session has an evaluation. Admins (`/admin/*`, and an admin reading their own session) always get values. This applies to every response that contains a `ResultCard` (`GET /sessions/{id}`, `TurnResponse.session`, `POST /finish`).
- **No real API calls in this phase** except the one `/models` read in T1. No spend.
- **Schema change without migrations.** SQLite `create_all` does not add columns to existing tables. Add a start-up check that fails fast with a clear message ("database schema is older than v1.2 — delete data/*.db or use a new DATABASE_PATH") when a required column is missing. Do not write a migration framework.
- **Git (D-027, D-033):** `git add -- backend` then `git commit -m "backend: …" -- backend`. Never commit `.env` or `backend/data/`.
- **Per-task loop:** implement → tests → `uv run pytest -q`, `uv run ruff check .`, `uv run ruff format --check .` green, guard coverage 100% → update `backend/docs/progress.md` and `backend/docs/decisions.md` → commit.

## 3. Tasks

### T1 — Pricing in the registry

- Add a top-level `pricing` map to `config/agents.yaml`, keyed by model slug:
  ```yaml
  pricing:
    openai/gpt-5.4: { input_per_mtok: 0.0, output_per_mtok: 0.0, source: openrouter-models, as_of: "2026-09-30" }
  ```
  Fill the seven models from `GET https://openrouter.ai/api/v1/models` (`pricing.prompt` and `pricing.completion` are USD **per token**; multiply by 1,000,000). Keep full precision; no rounding.
- If `/models` lists extra price fields for a model (e.g. `internal_reasoning`, `input_cache_read`), record them in the B-decision but do not model them in this phase.
- Registry validation (Pydantic): every model referenced by any agent (enabled or not) must have a pricing entry; prices are ≥ 0; unknown keys fail. `pricing` is included in the per-session config snapshot (B-015) so a later price edit does not change past sessions' estimates.
- `list-agents` shows the two prices per agent.

**Tests:** a missing price → validation error naming the model; negative price → error; snapshot contains the prices; reload with changed prices affects only new sessions.
**Done when:** the tests pass and the seven prices are filled with `as_of`.

### T2 — Per-call estimate and session totals

- `llm_calls` gains `price_input_per_mtok`, `price_output_per_mtok`, `estimated_cost_usd` (nullable when usage is missing).
- Determine from the phase-2b and 2b-2 traces (the stored `llm_calls` or `--json` files) whether each provider's `completion_tokens` **already includes** `reasoning_tokens`. Record the finding per model in a B-decision with the evidence (e.g. `completion_tokens ≥ reasoning_tokens` and the reported cost matching the formula). Then define `billable_output_tokens` accordingly (usually `completion_tokens`; add `reasoning_tokens` only for a provider where the evidence shows they are separate). If the evidence is unclear, use `completion_tokens` and say so.
- `estimated_cost_usd = (prompt_tokens × input + billable_output_tokens × output) / 1e6`, computed when the trace is written, for **every attempt** including failed and repair attempts that report usage.
- `sessions` gains `llm_call_count`, `total_prompt_tokens`, `total_completion_tokens`, `total_reasoning_tokens`, `total_estimated_cost_usd`, updated after every attempt (same place that updates `total_cost_usd` today). A token total stays `null` until at least one call reported that value.
- The start-up schema check from §2.

**Tests (FakeLLM):** the estimate formula with known numbers; a call without usage → `null` estimate and no change to token totals; totals over a structured session with a repair (turn + repair + assessment) equal the sum of the three traces; `llm_call_count` counts failed attempts; the schema check fails on a table without the new columns (build an old-schema SQLite file in the test).
**Done when:** the tests pass.

### T3 — API fields and blindness (contract v1.2)

- `ResultCard.stats`: add `llm_calls`, `prompt_tokens`, `completion_tokens`, `reasoning_tokens` from the session totals.
- Apply the blindness rule of §2 in one place (the function that builds the `ResultCard` for a given caller), not per endpoint.
- `MetricsRow`: add `total_cost_usd` (sum of reported cost over completed sessions with a non-null cost), `mean_llm_calls`, `mean_prompt_tokens`, `mean_completion_tokens`, `mean_reasoning_tokens` (means over completed sessions with a non-null value). Same grouping rules as B-021.
- CSV export: the new columns appear automatically (B-022); verify.

**Tests:** evaluator before evaluation → the five fields are `null` in `GET /sessions/{id}`, in the `TurnResponse` that completes the session, and in `POST /finish`; after evaluation → values; admin via `/admin/sessions/{id}` → values at any time; an admin who owns an unevaluated session → values; `MetricsRow` new fields for each `group_by` with known FakeLLM usage; the `sessions` and `llm_calls` CSV headers contain the new columns; the full existing suite still passes (update the schema key sets in existing tests).
**Done when:** the tests pass.

### T4 — `cost-report` CLI

`uv run python -m app.cli cost-report [--by session|agent|model|architecture] [--status completed|all] [--csv PATH]` (default `--by agent --status completed`):

- Columns: group key, sessions, LLM calls, repair calls, prompt / completion / reasoning tokens (sum and mean per session), reported cost (sum, mean, median, max per session), estimated cost (sum, mean), and the difference `(estimated − reported) / reported` in %. Mark rows where the absolute difference exceeds 15%.
- `--by session` lists one row per session: session id, agent id, model, architecture, status, end reason, questions, final triage level, calls, tokens, reported and estimated cost.
- Works without the OpenRouter key (it reads the DB only). It uses `DATABASE_PATH`, or `--db PATH`.
- Document it in the README with an example.

**Tests:** a seeded DB with known sessions and calls → exact aggregates for each `--by`; the 15% marker; the CSV file matches the table (UTF-8 with BOM, like the exports); an empty DB prints a clear "no sessions" line and exits 0.
**Done when:** the tests pass.

### T5 — Verify with the dev server and DemoLLM

DemoLLM must report plausible usage (fixed token counts per call and a small fixed cost) so the new fields can be seen end-to-end. Run `uv run python -m app.dev_server --seed` on a **new** DB (delete `data/dev.db` first — say so in the log), complete one structured and one simple session as `doctor`, evaluate one of them, and check with `Invoke-RestMethod`: the unevaluated one shows `null` stats fields, the evaluated one shows values, and `/admin/metrics` shows the new fields. Run `cost-report --by session` against `data/dev.db`.

**Tests:** DemoLLM usage values are deterministic (unit test).
**Done when:** the manual check passes; paste the outputs into the report.

### T6 — Report

Write **`backend/docs/reports/phase-2c-cost-accounting.md`** in English: summary; the price table (model, input, output per 1M tokens, source, as_of, any extra price fields seen); the reasoning-token finding per model with evidence; an **estimated cost per triage per agent** computed from the phase-2b-2 smoke runs (current model set) (tokens × prices, clearly labelled "estimate from smoke conversations, not real sessions"); the API/metrics changes; the schema-check behavior and the instruction to delete old DB files; new B-decisions; known issues; next steps. Update `progress.md`, `decisions.md`, README.

**Done when:** the report is written and everything is committed.

## 4. Definition of done (phase)

- Prices for all seven models are in `agents.yaml`, validated and snapshotted per session.
- Every LLM call stores tokens, reported cost, price snapshot, and estimated cost; sessions store totals.
- Contract v1.2 fields are served, with cost/tokens/calls hidden from non-admins until evaluation.
- `cost-report` works for all groupings and writes CSV.
- Tests, ruff, guard coverage green; report, progress, decisions committed with `backend:` prefixes; no API spend.
