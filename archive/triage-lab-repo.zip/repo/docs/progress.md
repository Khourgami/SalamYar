# Progress

Milestone-level status, maintained by Vahid + Claude chat. Task-level progress lives in `backend/docs/progress.md` and `web/docs/progress.md`.

| Milestone | Description | Owner | Status |
|---|---|---|---|
| M0 | Docs + API contract v1 frozen + repo structure | Vahid | ✅ Done (2026-09-29) |
| M1 | Backend core, architectures A/B, guard, tracing, tests | Backend coder | ⏳ Not started |
| M1' | Frontend against MSW mocks | Frontend coder | ⏳ Not started |
| M2 | Integration + `smoke-test` passes for all enabled agents | Both | ⏳ Not started |
| M3 | Internal QA (~10 role-play cases) and prompt tuning | Vahid | ⏳ Not started |
| M4 | Physician evaluation period | Physicians | ⏳ Not started |
| M5 | Decision report | Vahid | ⏳ Not started |

## Log

- 2026-09-29 — Initial documentation set created: PRD, ARCHITECTURE, AGENT_SPEC, API_CONTRACT, UI_SPEC, decisions, progress.
- 2026-09-29 — Repo restructured into root `docs/`, `backend/`, `web/`; `CLAUDE.md` (backend) and `AGENTS.md` (web) added.
