# Contract Change Requests (backend → product)

Use this file when `../../docs/API_CONTRACT.md` blocks or conflicts with the implementation. Keep implementing the contract as written until a request is accepted.

| # | Date | Contract section | Problem | Proposed change | Status (open/accepted/rejected) |
|---|---|---|---|---|---|
