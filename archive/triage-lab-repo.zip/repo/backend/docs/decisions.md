# Backend Decisions (B-xxx)

Implementation-level decisions for `backend/`. Cross-cutting decisions are in `../../docs/decisions.md` (read-only for this project).

| ID | Date | Decision | Rationale | Status |
|---|---|---|---|---|
