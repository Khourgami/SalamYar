# Web Progress

Updated by the web coder at the end of every task.

## Current status
Not started.

## Log
<!-- - YYYY-MM-DD — task — what was done — tests — next -->
