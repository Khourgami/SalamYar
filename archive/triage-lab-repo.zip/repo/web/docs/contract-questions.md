# Contract Questions (web → product)

Use this file when `../../docs/API_CONTRACT.md` or `UI_SPEC.md` is unclear or missing something. Keep building with the most conservative assumption and record it as a `W-xxx` decision.

| # | Date | Doc & section | Question | Assumption used meanwhile | Status (open/answered) |
|---|---|---|---|---|---|
