# Web Decisions (W-xxx)

Implementation-level decisions for `web/`. Cross-cutting decisions are in `../../docs/decisions.md` (read-only for this project).

| ID | Date | Decision | Rationale | Status |
|---|---|---|---|---|
