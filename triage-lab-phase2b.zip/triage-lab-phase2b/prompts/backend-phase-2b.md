# Backend Phase 2b — Real-Model Verification

You are a **senior Python backend engineer** with hands-on experience integrating LLM APIs through OpenRouter and diagnosing provider-specific behavior (JSON modes, parameter support, latency). You continue the `backend/` project of the AI Triage Agent Lab. Backend phase 2 and web phases 2–3 are complete: the whole app works end-to-end against the offline dev server with zero contract drift. **The only unverified path is backend → OpenRouter → the six real models.** This phase closes it (D-030). The machine is Windows 11 with Docker Desktop; use PowerShell-compatible commands.

## 1. Read first

1. `backend/CLAUDE.md`
2. `docs/decisions.md` — especially D-022, D-025, D-030, D-033
3. `backend/docs/BACKEND_ARCHITECTURE.md` (§6.1 greeting fallback, §8 registry, §9 OpenRouter), `backend/docs/AGENT_SPEC.md` §9
4. `backend/docs/reports/phase-2-integration-readiness.md` — §3 (the empty smoke table), §7 known issues 1–4, §8
5. `backend/docs/decisions.md`, `backend/docs/progress.md`, `backend/README.md`

## 2. Rules

- **Boundary.** Write only inside `backend/` (plus the root `docker-compose.yml` if a fix is truly required; record why). Never edit `docs/`, `web/`, `AGENT_SPEC.md`, or `BACKEND_ARCHITECTURE.md`.
- **Prompts are frozen.** No change to `app/agents/prompts/v1/`. No prompt tuning, no new prompt version. Prompt quality is the next phase, after human QA.
- **Budget.** The whole phase may spend at most **USD 5** of reported OpenRouter cost. Track the cumulative cost after every run (from the smoke output / `llm_calls.cost_usd`) and stop real calls when the next run could exceed it. Report where you stopped.
- **Evidence only (D-025).** Config changes are allowed only through the rule table in T3, each backed by the provider's error text or the trace. Observations such as "`/models` does not list `temperature`" are **not** evidence on their own; they only tell you what to look at first.
- **Never print or log the key.** Do not paste request headers into the report.
- **Git (D-027, D-033).** Commit with an explicit pathspec: `git add -- backend` then `git commit -m "backend: …" -- backend` (add `docker-compose.yml` to both only if you changed it). Never commit `.env` or `backend/data/`. If `.git/index.lock` exists, wait and retry; never delete it.
- **Per-task loop:** implement → tests → `uv run pytest -q`, `uv run ruff check .`, `uv run ruff format --check .` green (guard coverage still 100%) → update `backend/docs/progress.md` and `backend/docs/decisions.md` → commit.

## 3. Tasks

### T1 — Preconditions

- Confirm that `backend/.env` exists and defines `OPENROUTER_API_KEY` and `JWT_SECRET` (check presence only; never print values). If the key is missing, **stop the phase** and report it.
- Check the key without spending: `GET {OPENROUTER_BASE_URL}/key` (or the current equivalent endpoint in OpenRouter's docs) must return 200. Record the remaining credit/limit if the response includes it (numbers only).
- Add a "Phase 2b" task table (T1–T6) to `backend/docs/progress.md`.

**Done when:** the key is valid. **Tests:** none.

### T2 — Smoke table: per-turn latency

Extend the `smoke-test` output (phase-2 report §7.4) so each agent row shows, in addition to the current columns: the latency of each scripted turn, the mean and max turn latency, the number of LLM calls, the number of repair calls, and the cost. Add a `--json <path>` option that writes the same data (one object per agent, including the error text of any failed call, truncated to 500 characters) for the report.

**Tests:** FakeLLM-based unit tests for the new columns and the JSON file (per-turn latencies, repair count, error text truncation). No network.
**Done when:** the tests pass.

### T3 — Real smoke test and the D-025 fixes

1. Run `uv run python -m app.cli smoke-test --include-disabled --json data/smoke-run1.json`. Then run it a second time (`smoke-run2.json`).
2. For every failure, open the trace (`--json` error text and/or the `llm_calls` rows) and classify it. Apply **only** these fixes, per model (to both of its agents), each with a YAML comment `# B-0xx` and a `B-xxx` decision that quotes the provider's error text:

   | Evidence | Fix |
   |---|---|
   | The provider rejects `temperature` | `send_temperature: false` for that model |
   | The provider rejects `response_format` / `json_object` | `output_mode: prompt_only` for that model |
   | The provider rejects the `reasoning` parameter or the effort value | `reasoning_effort: null` for that model |
   | Any model rejects, or answers wrongly, a conversation whose first non-system message is `assistant` (architecture A) | Greeting fallback for **all** architecture-A agents (`BACKEND_ARCHITECTURE.md §6.1`): omit leading greeting messages from the LLM message list; DB and API unchanged. Unit-test the message builder. |
   | A transport timeout (60 s) on a single call, reproducible in both runs | No config change. Report it with the measured latencies. |
   | Invalid JSON that survives the repair, or anything else | **No fix.** Keep the config and the `enabled` flag unchanged; report it with the trace excerpt. |

3. After fixes, re-run the smoke test (within budget) until every agent passes or each remaining failure is in a "no change" row.
4. Keep the final `--json` files out of git (`data/` is ignored) and copy their summary into the report.

**Tests:** any code change (greeting fallback) has unit tests; the registry validation tests pass with the final `agents.yaml`.
**Done when:** a final smoke run exists for all 12 agents and every config change has a decision.

### T4 — Latency and repair check against the targets

From the final smoke run, compute per agent: p50 and max turn latency, the repair rate (repair calls / all calls), and the cost per scripted conversation. Compare with NFR-2 (p50 ≤ 8 s, p90 ≤ 20 s), the LLM timeout (60 s + 1 retry), and the web client's 90 s turn timeout. For architecture B, also report the conclusion turn separately (turn call + assessment call), since it is the longest.

Do **not** change timeouts, `reasoning_effort` levels, or models to meet the targets. Write the findings and the options (for example "lower `reasoning_effort` for model X", "disable agent Y") as **recommendations for the product owner** in the report.

**Tests:** none (analysis). **Done when:** the table and recommendations are in the report draft.

### T5 — Real-model smoke through Docker Compose and nginx

This replaces web phase 3 T5 (D-030). It must not leave test data in the real database.

1. If `backend/data/lab.db` exists, stop any running stack and copy `lab.db`, `lab.db-wal`, `lab.db-shm` to `backend/data/backup-before-2b/`.
2. `docker compose up --build -d` from the root.
3. Create an evaluator inside the container with the documented `--password-stdin` command.
4. Through `http://localhost` (nginx, not port 8000), with `Invoke-RestMethod`: log in; `GET /agents`; create a session with `b-sonnet5` and one with `a-gpt54`; in each, send **two** short patient messages (e.g. «از دیروز سردرد دارم», then an answer to the agent's question) and record each turn's HTTP status, wall-clock latency, `agent_message.kind`, and the Persian text of the reply (first 200 characters).
5. `POST /finish` on one of the two sessions and confirm a `result` with a `ResultCard`.
6. `docker compose down`. Delete the `lab.db*` files the check created, then restore the backup from step 1 if there was one. Confirm with a directory listing.

**Tests:** none automated; paste the commands and results (without the token or password) into the report.
**Done when:** real replies arrived through nginx for both architectures and the database is back to its prior state.

### T6 — Report

- Leave the phase-2 report unchanged. Write a new report **`backend/docs/reports/phase-2b-real-model-verification.md`** in English:
  1. summary (pass/fail per agent, total spent);
  2. the smoke results table (agent, model, `output_mode`, `send_temperature`, `reasoning_effort`, run 1 / run 2 / final, repairs, p50 / max turn latency, conclusion-turn latency for B, cost per conversation);
  3. every config change with the quoted evidence and its `B-xxx`;
  4. failures kept unchanged, with trace excerpts;
  5. the T4 comparison with NFR-2 and the recommendations for the product owner;
  6. the T5 compose run (commands, statuses, latencies, reply excerpts);
  7. a short qualitative note per model on the Persian replies seen in the runs (natural or stiff, number of questions per message, any English words, any drug advice) — observations only, no prompt changes;
  8. known issues and next steps.
- Update `backend/docs/progress.md`, `backend/docs/decisions.md`, and the README smoke-test section if its usage changed.

**Done when:** the report is written and everything is committed.

## 4. Definition of done (phase)

- A final real smoke run covers all 12 agents; every enabled agent passes, or each failure is documented as "no change" with evidence.
- Every config change is evidence-backed and recorded (`B-xxx`, YAML comment).
- Real replies were received through nginx for both architectures, and the real database was left as it was.
- Total spend ≤ USD 5, reported.
- Tests, ruff, and guard coverage green; report, progress, and decisions committed with `backend:` prefixes.
